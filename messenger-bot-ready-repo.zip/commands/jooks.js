module.exports.config = {
  name: "jooks",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Abrar Fahim",
  description: "Send Bengali jokes.",
  commandCategory: "Fun",
  usages: "[jooks]",
  cooldowns: 3
};

module.exports.run = async function({ api, event }) {
  return api.sendMessage("Send Bengali jokes.", event.threadID);
};