module.exports.config = {
  name: "motivation",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Abrar Fahim",
  description: "Send motivational quotes.",
  commandCategory: "Fun",
  usages: "[motivation]",
  cooldowns: 3
};

module.exports.run = async function({ api, event }) {
  return api.sendMessage("Send motivational quotes.", event.threadID);
};