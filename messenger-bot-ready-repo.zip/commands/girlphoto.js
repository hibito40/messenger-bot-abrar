module.exports.config = {
  name: "girlphoto",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Abrar Fahim",
  description: "Send random girl photo.",
  commandCategory: "Fun",
  usages: "[girlphoto]",
  cooldowns: 3
};

module.exports.run = async function({ api, event }) {
  return api.sendMessage("Send random girl photo.", event.threadID);
};