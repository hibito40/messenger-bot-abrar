module.exports.config = {
  name: "photo",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Abrar Fahim",
  description: "Send random image.",
  commandCategory: "Fun",
  usages: "[photo]",
  cooldowns: 3
};

module.exports.run = async function({ api, event }) {
  return api.sendMessage("Send random image.", event.threadID);
};