module.exports.config = {
  name: "say",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Abrar Fahim",
  description: "Repeat user input.",
  commandCategory: "Fun",
  usages: "[say]",
  cooldowns: 3
};

module.exports.run = async function({ api, event }) {
  return api.sendMessage("Repeat user input.", event.threadID);
};