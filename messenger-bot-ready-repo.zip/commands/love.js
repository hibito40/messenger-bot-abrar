module.exports.config = {
  name: "love",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Abrar Fahim",
  description: "Send romantic lines.",
  commandCategory: "Fun",
  usages: "[love]",
  cooldowns: 3
};

module.exports.run = async function({ api, event }) {
  return api.sendMessage("Send romantic lines.", event.threadID);
};