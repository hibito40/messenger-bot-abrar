module.exports.config = {
  name: "pair",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Abrar Fahim",
  description: "Make funny pairs.",
  commandCategory: "Fun",
  usages: "[pair]",
  cooldowns: 3
};

module.exports.run = async function({ api, event }) {
  return api.sendMessage("Make funny pairs.", event.threadID);
};