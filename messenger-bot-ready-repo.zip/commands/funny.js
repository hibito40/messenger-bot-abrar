module.exports.config = {
  name: "funny",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Abrar Fahim",
  description: "Send funny jokes.",
  commandCategory: "Fun",
  usages: "[funny]",
  cooldowns: 3
};

module.exports.run = async function({ api, event }) {
  return api.sendMessage("Send funny jokes.", event.threadID);
};