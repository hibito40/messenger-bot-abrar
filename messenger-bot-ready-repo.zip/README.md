# Messenger Bot 🤖

A fun, educational, and romantic Messenger chatbot powered by Node.js.

## Features

- 🗣 Say command
- 😂 Funny jokes
- 💌 Love quotes
- 🔥 Motivation
- 🖼️ Random photos
- 👧 Girl photo
- 😂 Jooks
- ❤️ Pair maker

## Usage

Add your commands in the `commands/` folder and run the bot using your preferred Node.js environment.